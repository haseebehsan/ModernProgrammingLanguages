Uber-Android-Clone
==================
Uber android application clone

Create Secrets.java under com/bharathmg/bookmyride/com/bharathmg/bookmyride/helpers/Secrets/Secrets.java package and 
save your  PLACES_API_KEY = "YOUR_API_KEY" as a constant.

In debug/res/values/google_maps_api.xml, save your MAPS_API_KEY.

Then you can ``run`` the app.
